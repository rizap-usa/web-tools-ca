import pyodbc
import sqlite3
from logger import *



class DBConnect(object):
    def __init__(self):
        # Connection Setting
        self._server = 'rizap-official.database.windows.net'
        self._database = 'Rizap-Official'
        self._username = 'RizapAdmin'
        self._password = 'pZC0FvGT175CIgy4W3P0'
        self._driver = '{ODBC Driver 17 for SQL Server}'

        # Manage Element
        self._cursor = None

    def db_connect(self):
        try:
            conn = pyodbc.connect('DRIVER='+self._driver+';SERVER='+self._server+';PORT=1433;DATABASE='+self._database+';UID='+self._username+';PWD='+ self._password)
            self._cursor = conn.cursor()
            Logger.write(Category.MainApp, Severity.VERBOSE, "Connect to DB successful!")
        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "DB Connect Fail, Get Error: {}".format(str(E)))

    def get_data(self, sql_string):
        Logger.write(Category.MainApp, Severity.INFO, "get data sql = {}".format(sql_string))

        try:
            self._cursor.execute(sql_string)
            row = self._cursor.fetchall()

            Logger.write(Category.MainApp, Severity.VERBOSE, "Get query data successful: {}".format(row))
        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "Query Data Failed, Get Error: {}".format(str(E)))
            row = None

        return row

    def weitr_date(self, sql_string):
        Logger.write(Category.MainApp, Severity.INFO, "get data sql = {}".format(sql_string))

        try:
            self._cursor.execute(sql_string)
            self._cursor.commit()

            Logger.write(Category.MainApp, Severity.VERBOSE, "Set  data successful")
            ret = True
        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "Query Data Failed, Get Error: {}".format(str(E)))
            ret = False

        return ret

