# -*- coding: UTF-8 -*-
# encoding: utf-16

from DBConnect import *
import csv
from datetime import datetime, timedelta
import time


class ExpireProcess(object):
    def __init__(self):
        self._query_start_time = None
        self._query_end_time = None
        self._db_access = DBConnect()

        # RAW Data
        self._db_product_list = None
        self._db_contract_product_list = None

        # init the DB
        self._db_access.db_connect()

    """
    1. Rule get the check info [GuestManagementAttendances]
    2. According to the check contract find the owner [GuestManagementContractForms]
    3. Find the course id --> [GuestManagementContractForms] item CourseDbId
    4. Find the Course info [SettingCourse] available month
    5. Update the expire date [GuestManagementContractForms].expiredate
    """
    def routine_runner(self):
        export_list = []

        sql_string = "SELECT * FROM [dbo].[GuestManagementAttendances] "
        checkin_list = self._db_access.get_data(sql_string)


        sql_string = "SELECT * FROM [dbo].[GuestManagementContractForms]"
        contract_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[SettingCourse]"
        course_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementSaleses]"
        sales_list = self._db_access.get_data(sql_string)

        now_date = datetime.now()

        # Step 0.1. Find the detail info
        for contract_item in contract_list:
            # print("-->{} | {}".format(contract_item[43], datetime(1,1,1)))
            if contract_item[43] == datetime(1, 1, 1) and contract_item[49] == 'Contracted':
                print("-------------------{}------------{}".format(contract_item[42], contract_item[9]))

                target_id = contract_item[0]

                # Step 3. Add the target expire date correct
                expire_date = datetime(1, 1, 1)
                sql_string = "update [dbo].[GuestManagementContractForms] set ExpirationDate = '{}' where id = '{}'".format(
                    expire_date, target_id)
                self._db_access.weitr_date(sql_string)

            elif contract_item[43] != datetime(1, 1, 1):
                course_id = contract_item[26]
                target_id = contract_item[0]

                # Step 2. find the course detail
                for course_item in course_list:
                    if course_item[0] == course_id:
                        # Findn the target
                        avail_month = course_item[10]
                        break

                # Step 3. set the correct expired date
                expire_date = contract_item[43] + timedelta(days=int(avail_month) * 31)
                sql_string = "update [dbo].[GuestManagementContractForms] set ExpirationDate = '{}' where id = '{}'".format(
                    expire_date, target_id)
                self._db_access.weitr_date(sql_string)
                print("---->> {}".format(sql_string))



class DataFilter(object):
    def __init__(self):
        self._query_start_time = None
        self._query_end_time = None
        self._db_access = DBConnect()

        # RAW Data
        self._db_product_list = None
        self._db_contract_product_list = None

        # init the DB
        self._db_access.db_connect()

    """
    1. Rule get the check info [GuestManagementAttendances]
    2. According to the check contract find the owner [GuestManagementContractForms]
    3. Find the course id --> [GuestManagementContractForms] item CourseDbId
    4. Find the Course info [SettingCourse] available month
    5. Update the expire date [GuestManagementContractForms].expiredate
    """

    def routine_runner(self):
        export_list = []

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractForms]"
        contract_list = self._db_access.get_data(sql_string)
        target_start_date = datetime(year=2021, month=2, day=26).date()
        for contract_item in contract_list:

            if contract_item[49] == 'Completed':
                if contract_item[5].date() >= target_start_date and contract_item[45] > 0:
                    # Find the error contract
                    print("---------------------------\n->FullName: {}\n->Contract: {}\n->ExpireDate->{}\n----------------".format(contract_item[9], contract_item[42], contract_item[5]))



if __name__ == '__main__':
    #PP = ProductProcess()
    #PP.export_product()

    #PA = AdmissionFeeProcess()
    #PA.export_product()


    while True:
        EP = ExpireProcess()
        EP.routine_runner()

        time.sleep(43200)

    #DF = DataFilter()
    #DF.routine_runner()