環境
Python3.8

額外安裝 (用 pip3 install):
pyodbc
PyQt5

手動安裝(用 python setup.py install)
logger (附件內含setup.py)