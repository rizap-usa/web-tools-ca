# -*- coding: UTF-8 -*-
# encoding: utf-16

from DBConnect import *
import csv
from datetime import datetime


class CheckAccessKey(object):
    def __init__(self):
        self._db_access = DBConnect()


class DataToCsv(object):
    def __init__(self, file_name):
        self._file_name = file_name

    def export_csv(self, data_list):
        Logger.write(Category.MainApp, Severity.VERBOSE, "Start Export CSV")
        with open(self._file_name, "w", newline='', encoding='utf-8') as csv_file:
            csv_file.write('\ufeff')
            writer = csv.writer(csv_file, delimiter=',')
            Logger.write(Category.MainApp, Severity.INFO, "Create File [{}] Successful".format(self._file_name))

            for file_item in data_list:
                try:
                    writer.writerow(file_item)
                except Exception as E:
                    Logger.write(Category.MainApp, Severity.WARNING, "Export CSV Fail, Get Error: {}".format(str(E)))


class AdmissionFeeProcess(object):
    def __init__(self):
        self._db_access = DBConnect()

        # RAW Data
        self._db_adfee_list = None
        self._db_contract_product_list = None

        # init the DB
        self._db_access.db_connect()

        # CSV transfer
        date_now = datetime.now()
        file_name = "admission_fee_{}.csv".format(date_now.strftime("%Y-%m-%d_%H%M"))
        self._csv_writer = DataToCsv(file_name)

    def get_access_permission(self):
        try:
            sql_string = "SELECT * FROM [dbo].[ToolAccessKey]"
            access_list = self._db_access.get_data(sql_string)

            if access_list is None:
                Logger.write(Category.MainApp, Severity.WARNING, "Can not get the access list")
            else:
                Logger.write(Category.MainApp, Severity.INFO, "Get Access List as {}".format(access_list))
                Logger.write(Category.MainApp, Severity.INFO, "Get Key Access data as {}".format(access_list[0][0]))

                if access_list[0][0] == 1:
                    # Check Access Key
                    return True
                else:
                    return False

        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "get_access_permissionFail, Get Error: {}".format(str(E)))

    def _get_data(self):
        export_list = []

        sql_string = "SELECT * FROM [dbo].[GuestManagementSaleses]"
        admifee_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementMains]"
        guest_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[Staffs]"
        staff_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[SettingCourse]"
        course_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractFormPaymentSchedules]"
        payment_list = self._db_access.get_data(sql_string)
        payment_list.sort(key=lambda s:s[1])

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractForms]"
        contract_list = self._db_access.get_data(sql_string)

        for admifee_item in admifee_list:
            data_list = []
            if admifee_item[4] == "Admission fee":
                # Find the traget item
                csv_first_date = admifee_item[3]
                csv_store = admifee_item[10]
                csv_contract_id = admifee_item[9]
                contract_id = admifee_item[9]
                staff_id = admifee_item[8]
                guest_id = admifee_item[7]

                for guest_item in guest_list:
                    if guest_item[0] == guest_id:
                        csv_guest_name = guest_item[7]
                        csv_guest_id = guest_item[6]

                for staff_item in staff_list:
                    if staff_item[0] == staff_id:
                        csv_staff_name = staff_item[5]

                for contract_item in contract_list:
                    if contract_item[42] == contract_id:
                        csv_course_name = contract_item[27]
                        csv_contract_quantity = contract_item[5]
                        csv_contract_create_time = contract_item[52]
                        csv_admifee = contract_item[24]
                        csv_coursse_id = contract_item[26]
                        contract_db_id = contract_item[0]


                for payment_item in payment_list:
                    if payment_item[3] == contract_db_id:
                        csv_invoice_number = payment_item[11]
                        csv_invoice_create_time = payment_item[1]
                        print("=========={}".format(csv_invoice_create_time))
                        break


                for course_item in course_list:
                    if course_item[0] == csv_coursse_id:
                        csv_contract_length = course_item[10]

                data_list.append(csv_first_date.strftime("%Y-%m-%d"))
                data_list.append(csv_store)
                data_list.append(csv_guest_name)
                data_list.append(csv_guest_id)
                data_list.append(csv_contract_id)
                data_list.append(csv_staff_name)
                data_list.append(csv_course_name)
                data_list.append(csv_contract_length)
                data_list.append(csv_contract_create_time.strftime("%Y-%m-%d"))
                data_list.append(csv_admifee)
                data_list.append(round(int(csv_admifee) / 1.05, 2))
                data_list.append('')
                if csv_invoice_number is None:
                    data_list.append('')
                else:
                    data_list.append(csv_invoice_create_time.strftime("%Y-%m-%d"))
                data_list.append(csv_invoice_number)

            if len(data_list) > 0:
                export_list.append(data_list)

        return export_list

    def export_admissionfee_with_date(self, start_date, end_date):
        data_list = self._get_data()
        final_list = []
        Logger.write(Category.MainApp, Severity.VERBOSE, "Get data_list: {}".format(data_list))

        fieldnames = ['首次課程日期',
                      '店鋪',
                      '客戶名稱',
                      '客戶編號',
                      '合約編號',
                      '負責教練',
                      '合約名稱',
                      '合約時間(月份)',
                      '合約簽訂日期',
                      '已認列入會費',
                      '已認列入會費(未稅)',
                      '發票種類',
                      '發票發行日期',
                      '發票號碼'
                      ]

        for data_item in data_list:
            data_date = datetime.strptime(data_item[0], '%Y-%m-%d')
            if start_date <= data_date <= end_date:
                final_list.append(data_item)
        # final data list
        final_list.insert(0, fieldnames)
        self._csv_writer.export_csv(final_list)

    def export_product(self):
        fieldnames = ['首次課程日期',
                      '店鋪',
                      '客戶名稱',
                      '客戶編號',
                      '合約編號',
                      '負責教練',
                      '合約名稱',
                      '合約時間',
                      '合約簽訂日期',
                      '已認列入會費',
                      '已認列入會費(未稅)',
                      '發票種類',
                      '發票發行日期',
                      '發票號碼'
                      ]

        data_list = self._get_data()
        data_list.insert(0, fieldnames)

        self._csv_writer.export_csv(data_list)


class ProductProcess(object):
    def __init__(self):
        self._query_start_time = None
        self._query_end_time = None
        self._db_access = DBConnect()

        # RAW Data
        self._db_product_list = None
        self._db_contract_product_list = None

        # init the DB
        self._db_access.db_connect()

        Logger.write(Category.MainApp, Severity.INFO, "After DB connection")
        # CSV transfer
        date_now = datetime.now()
        file_name = "product_{}.csv".format(date_now.strftime("%Y-%m-%d_%H%M"))
        self._csv_writer = DataToCsv(file_name)
        Logger.write(Category.MainApp, Severity.INFO, "After Data to CSV")

    def get_access_permission(self):
        Logger.write(Category.MainApp, Severity.INFO, "Start check permission")
        try:
            sql_string = "SELECT * FROM [dbo].[ToolAccessKey]"
            access_list = self._db_access.get_data(sql_string)
        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "Get Permission get Error: {}".format(str(E)))

        Logger.write(Category.MainApp, Severity.INFO, "Get Permission Key: {}".format(access_list[0][0]))

        if access_list[0][0] == 1:
            # Check Access Key
            return True
        else:
            return False

    def _get_product(self):
        export_list = []

        sql_string = "SELECT * FROM [dbo].[SettingProduct]"
        product_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractFormProducts]"
        contract_product_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractForms]"
        contract_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementMains]"
        guest_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[SettingCourse]"
        course_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractFormPaymentSchedules]"
        payment_list = self._db_access.get_data(sql_string)
        payment_list.sort(key = lambda s:s[1])


        Logger.write(Category.MainApp, Severity.INFO, "After Get all data list")

        for contract_product_item in contract_product_list:
            data_list = []
            adding_flag = True

            # Get the csv buy date
            csv_buy_date = contract_product_item[1]
            csv_buy_date = csv_buy_date.strftime("%Y-%m-%d")
            csv_product_price = contract_product_item[6]
            csv_product_quantity = contract_product_item[7]
            csv_total_price = int(csv_product_price) * int(csv_product_quantity)

            contract_db_id = contract_product_item[3]
            csv_product_name = contract_product_item[5]
            product_id = contract_product_item[4]

            for product_item in product_list:
                if product_item[4] == product_id:
                    csv_product_price_without_tax = product_item[9]
                    csv_total_price_without_tax = int(csv_product_price_without_tax) * int(csv_product_quantity)

            for contract_item in contract_list:
                if contract_item[0] == contract_db_id:
                    if contract_item[49] == "Withdrew":
                        adding_flag = False
                        break

                    # print("{}----------------{}".format(contract_item[0], contract_db_id))
                    # Find the contract, it have the buy location
                    csv_buy_store = contract_item[99]
                    csv_buy_user_name = contract_item[9]
                    csv_contract_id = contract_item[42]
                    csv_staff_name = contract_item[30]
                    csv_course_name = contract_item[27]
                    csv_pay_method = contract_item[81]

                    # Fuck relation item
                    course_db_id = contract_item[26]
                    for course_item in course_list:
                        if course_item[0] == course_db_id:
                            tax_rate = course_item[13]

                    guest_db_id = contract_item[4]
                    for guest_item in guest_list:
                        if guest_item[0] == guest_db_id:
                            csv_user_id = guest_item[6]

                if adding_flag is True:
                    for payment_item in payment_list:
                        # print("-------{}---------{}".format(payment_item[3], contract_db_id))
                        csv_payment_list = []
                        if payment_item[3] == contract_db_id:
                            csv_payment_list.append(payment_item[5].strftime("%Y-%m-%d"))
                            csv_payment_list.append(payment_item[4])
                            csv_invoice_number = payment_item[11]
                            csv_invoice_create_time = payment_item[1]
                            break

            Logger.write(Category.MainApp, Severity.INFO, "The add flag: {}".format(adding_flag))
            if adding_flag is True:
                data_list.append(csv_buy_date)
                data_list.append(csv_buy_store)
                data_list.append(csv_buy_user_name)
                data_list.append(csv_user_id)
                data_list.append(csv_contract_id)
                data_list.append(csv_staff_name)
                data_list.append(csv_product_name)
                data_list.append(csv_product_price)
                data_list.append(csv_product_price_without_tax)
                data_list.append(csv_product_quantity)
                data_list.append(csv_total_price)
                data_list.append(csv_total_price_without_tax)
                for csv_payment_item in csv_payment_list:
                    data_list.append(csv_payment_item)

                data_list.append(csv_pay_method)
                data_list.append('')

                if csv_invoice_number is not None:
                    data_list.append(csv_invoice_create_time.strftime("%Y-%m-%d"))
                else:
                    data_list.append('')
                data_list.append(csv_invoice_number)

                export_list.append(data_list)

        return export_list

    def export_product_with_date(self, start_date, end_date):
        data_list = self._get_product()
        final_list = []

        fieldnames = ['購買日期',
                      '店鋪',
                      '客戶名稱',
                      '客戶編號',
                      '合約編號',
                      '負責教練',
                      '產品名稱',
                      '產品單價',
                      '產品單價(未稅)',
                      '產品數量',
                      '合約總價(含稅)',
                      '合約原價(未稅)',
                      '付款日',
                      '金額',
                      '付款方式',
                      '發票種類',
                      '發票發行日期',
                      '發票號碼'
                      ]

        for data_item in data_list:
            data_date = datetime.strptime(data_item[0], '%Y-%m-%d')
            if start_date <= data_date <= end_date:
                final_list.append(data_item)

        # final data list
        try:
            final_list.insert(0, fieldnames)
            self._csv_writer.export_csv(final_list)
        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "Export Product Get Error: {}".format(str(E)))

    def export_product(self):
        fieldnames = ['購買日期',
                      '店鋪',
                      '客戶名稱',
                      '客戶編號',
                      '合約編號',
                      '負責教練',
                      '產品名稱',
                      '產品單價',
                      '產品單價(未稅)',
                      '產品數量',
                      '合約總價(含稅)',
                      '合約原價(未稅)',
                      '付款日',
                      '金額',
                      '付款方式',
                      '發票種類',
                      '發票發行日期',
                      '發票號碼'
                      ]

        data_list = self._get_product()
        data_list.insert(0, fieldnames)
        self._csv_writer.export_csv(data_list)


class ContractYearProcess(object):
    def __init__(self):
        self._query_start_time = None
        self._query_end_time = None
        self._db_access = DBConnect()

        # RAW Data
        self._db_product_list = None
        self._db_contract_product_list = None

        # init the DB
        self._db_access.db_connect()

        # CSV transfer
        date_now = datetime.now()
        file_name = "YearContract_{}.csv".format(date_now.strftime("%Y-%m-%d_%H%M"))
        self._csv_writer = DataToCsv(file_name)

        # repeat flag
        self._invoice_count = 0

    def get_access_permission(self):
        try:
            sql_string = "SELECT * FROM [dbo].[ToolAccessKey]"
            access_list = self._db_access.get_data(sql_string)

            if access_list is None:
                Logger.write(Category.MainApp, Severity.WARNING, "Can not get the access list")
            else:
                Logger.write(Category.MainApp, Severity.INFO, "Get Access List as {}".format(access_list))
                Logger.write(Category.MainApp, Severity.INFO, "Get Key Access data as {}".format(access_list[0][0]))

                if access_list[0][0] == 1:
                    # Check Access Key
                    return True
                else:
                    return False

        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "get_access_permissionFail, Get Error: {}".format(str(E)))

    def _process_old_data(self, contract_list):
        return_list = []

        """
        Calc the uncomplete contract value
        Due to the condition is too complex to implement, set a record here.
        """

    def _get_product(self, target_year=None):
        export_list = []
        current_year_list = []
        prior_year_list = []

        course_flag = False

        if target_year is None:
            target_year = datetime.now().strftime("%Y")

        sql_string = "SELECT * FROM [dbo].[GuestManagementAttendances]"
        checkin_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractForms]"
        all_contract_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementMains]"
        guest_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementSaleses]"
        sales_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractFormPaymentSchedules]"
        payment_list = self._db_access.get_data(sql_string)
        payment_list.sort(key=lambda s: s[1])

        # First filter, get only target year and before data
        # set target year start and end date
        contract_target_start_date = datetime(int(target_year), 4,1)
        contract_target_end_date = datetime(int(target_year)+1, 3,31)

        for all_contract_item in all_contract_list:
            contract_first_start_time = all_contract_item[52]
            contract_db_id = all_contract_item[0]
            csv_rebate_amount = all_contract_item[66]
            csv_handle_fee = all_contract_item[69]

            #if contract_target_start_date < contract_first_start_time < contract_target_end_date:
            if contract_first_start_time < contract_target_end_date:
                # This contract is create and defined in target year
                current_year_list.append(all_contract_item)
            elif contract_first_start_time < contract_target_start_date:
                # This contract is create before target year
                # Find the next key [status]-is Contracted/On Work/Extended/On Work
                if 'Contracted' in all_contract_item[49] or 'On Work' in all_contract_item[49]:
                    # Find the uncompleted contract, add to the list
                    prior_year_list.append(all_contract_item)

            else:
                # This item is out of range
                pass

        # Call other function to process the prior contract
        for contract_item in current_year_list:
            data_list = []

            csv_store = contract_item[99]
            csv_contract_create_time = contract_item[1]
            contract_db_id = contract_item[0]

            csv_payment_method = contract_item[39]
            csv_cancel_refound_amount = contract_item[38]

            # Rebate process
            rebate_amount = contract_item[37]

            if rebate_amount is not None:
                if "Rebate" in rebate_amount:
                    fuck_count = rebate_amount.count("Rebate_")

                    start_index = 0
                    total_fuck_amount = 0
                    for i in range(0, fuck_count):
                        fuck_1 = rebate_amount.find("Rebate_", start_index)
                        fuck_2 = rebate_amount.find("]", fuck_1) + 1
                        fuck_3 = rebate_amount.find("]", fuck_2)

                        fuck_amount = float(rebate_amount[fuck_2:fuck_3])
                        total_fuck_amount += fuck_amount
                        start_index = fuck_3 + 1

                    if total_fuck_amount != 0:
                        csv_rebate_amount = total_fuck_amount

            # Set the contract sign time, the real create time
            csv_contract_start_time = contract_item[52]
            csv_contract_start_time = csv_contract_start_time.strftime("%Y-%m-%d")

            csv_contract_create_time = csv_contract_create_time.strftime("%Y-%m-%d")
            csv_contract_id = contract_item[42]
            csv_user_fullname = contract_item[9]
            csv_staff_name = contract_item[30]
            csv_course_name = contract_item[27]
            csv_total_amount = contract_item[28]
            csv_contract_status = contract_item[49]
            # Translate
            if csv_contract_status == 'Contracted':
                csv_contract_status = '完全簽定'
            elif csv_contract_status == 'On Work':
                csv_contract_status = '執行中'
            elif csv_contract_status == 'Extended/ On Work':
                csv_contract_status = '延長合約執行中'
            elif csv_contract_status == 'Completed':
                csv_contract_status = '已完成合約'
            elif csv_contract_status == 'Withdrew':
                csv_contract_status = '取消合約'

            csv_session_quantity = contract_item[44]
            csv_session_suplus = contract_item[45]
            csv_session_usage = int(csv_session_quantity) - int(csv_session_suplus)
            csv_paid_amount = contract_item[100]
            csv_discount_amonut = contract_item[25]
            csv_calcel_handfee = contract_item[69]
            csv_4m_usage = 0
            csv_5m_usage = 0
            csv_6m_usage = 0
            csv_7m_usage = 0
            csv_8m_usage = 0
            csv_9m_usage = 0
            csv_10m_usage = 0
            csv_11m_usage = 0
            csv_12m_usage = 0
            csv_1m_usage = 0
            csv_2m_usage = 0
            csv_3m_usage = 0
            csv_session_count = 0
            csv_year_recognize_amount = 0
            csv_pre_lost = 0
            fuck_pre_access = 0
            csv_fuck_pre_year = 0

            contract_guid = contract_item[0]
            guest_db_id = contract_item[4]

            if csv_course_name == 'No Course':
                course_flag = False
            else:
                course_flag = True

                for guest_item in guest_list:
                    if guest_item[0] == guest_db_id:
                        csv_user_id = guest_item[6]

                for sales_item in sales_list:
                    if sales_item[9] == csv_contract_id and sales_item[5] != 'Cancellation':
                        target_start_date = datetime(year=int(target_year)-1, month=4, day=1).date()
                        target_end_date = datetime(year=int(target_year), month=3, day=31).date()
                        Logger.write(Category.MainApp, Severity.INFO, "-d1---{}-- {} ---{}".format(target_start_date, sales_item[3].date(), target_end_date))

                        if target_start_date >= sales_item[3].date() >= target_end_date:
                            csv_year_recognize_amount += sales_item[6]
                            Logger.write(Category.MainApp, Severity.INFO, "Add price -- {}".format(csv_year_recognize_amount))

                            if sales_item[4] == 'Session':
                                csv_pre_lost += 1
                        elif sales_item[3].date() > target_start_date:
                            csv_fuck_pre_year +=  sales_item[6]



                # Process the invoice
                # Get the invoice list
                csv_invoice_list = []
                contract_invoice_count = 0
                for payment_item in payment_list:
                    if payment_item[3] == contract_db_id:
                        if payment_item[11] is not None:
                            invoice_item = {"date": payment_item[1].strftime("%Y-%m-%d"),
                                            "method": csv_payment_method,
                                            "number": payment_item[11],
                                            "amount": payment_item[4],
                                            "p_date": payment_item[5].strftime("%Y-%m-%d")
                                            }
                            csv_invoice_list.append(invoice_item)
                            contract_invoice_count += 1
                            print("invoice-->{}".format(invoice_item))

                if contract_invoice_count > self._invoice_count:
                    self._invoice_count = contract_invoice_count
                    print("over write the count as: {}".format(self._invoice_count))
                else:
                    print("Don;t change the count as: {}".format(self._invoice_count))
                    pass

                # Get year checkin record
                for checkin_item in checkin_list:
                    if checkin_item[3] == guest_db_id and checkin_item[7] == contract_guid:
                        # find the check record, start fillter
                        checkin_date = checkin_item[1].strftime("%Y-%m")
                        if checkin_date == '{}-04'.format(target_year):
                            csv_4m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-05'.format(target_year):
                            csv_5m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-06'.format(target_year):
                            csv_6m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-07'.format(target_year):
                            csv_7m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-08'.format(target_year):
                            csv_8m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-09'.format(target_year):
                            csv_9m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-10'.format(target_year):
                            csv_10m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-11'.format(target_year):
                            csv_11m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-12'.format(target_year):
                            csv_12m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-01'.format(int(target_year) + 1):
                            csv_1m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-02'.format(int(target_year) + 1):
                            csv_2m_usage += 1
                            csv_session_count += 1
                        elif checkin_date == '{}-03'.format(int(target_year) + 1):
                            csv_3m_usage += 1
                            csv_session_count += 1
                        else:
                            csv_session_count += 1
                            fuck_pre_access += 1

                # Add the result list
                data_list.append(csv_store)
                data_list.append(csv_user_fullname)
                data_list.append(csv_user_id)
                data_list.append(csv_contract_id)
                data_list.append(csv_staff_name)
                data_list.append(csv_course_name)
                data_list.append(csv_contract_start_time)  # Change to contract first start time, not create time
                data_list.append(csv_total_amount)
                data_list.append(round(int(csv_total_amount) / 1.05, 2))
                data_list.append(csv_contract_status)

                try:
                    csv_data_session_unit_price = round(int(csv_total_amount) / int(csv_session_quantity), 2)
                    csv_data_session_unit_price_without_tax = round(csv_data_session_unit_price / 1.05, 2)
                except Exception as E:
                    Logger.write(Category.MainApp, Severity.INFO, "unit price error--{}--{}".format(csv_session_quantity, str(E)))
                    csv_data_session_unit_price = 0
                    csv_data_session_unit_price_without_tax = 0

                if csv_contract_status == 'Withdrew':
                    data_list.append(csv_session_quantity)
                    data_list.append(csv_session_count)
                    data_list.append(0)
                    data_list.append(csv_session_quantity - csv_session_count)
                    csv_total_recognize_amount = 0
                    csv_total_recognize_amount_without_tax = 0
                    csv_total_unrecognize_amount = csv_total_amount
                    csv_total_unrecognize_amount_without_tax = round(csv_total_amount / 1.05, 2)

                else:
                    data_list.append(csv_session_quantity)
                    data_list.append(csv_session_count)
                    data_list.append(csv_session_quantity - csv_session_count)
                    data_list.append(0)
                    csv_total_recognize_amount = int(csv_session_usage) * int(csv_data_session_unit_price)
                    csv_total_recognize_amount_without_tax = round(csv_total_recognize_amount / 1.05, 2)
                    csv_total_unrecognize_amount = csv_total_amount - csv_total_recognize_amount
                    csv_total_unrecognize_amount_without_tax = round(csv_total_unrecognize_amount / 1.05, 2)

                # calc the unpay
                csv_unpay_amount = csv_total_amount - csv_paid_amount

                data_list.append(csv_data_session_unit_price)
                data_list.append(csv_data_session_unit_price_without_tax)

                data_list.append(csv_session_quantity - fuck_pre_access)
                # New item
                #data_list.append(round(csv_year_recognize_amount, 2))
                #data_list.append(round((csv_paid_amount-csv_year_recognize_amount)/1.05, 2))
                data_list.append(round(fuck_pre_access * csv_data_session_unit_price, 2))
                data_list.append(round((csv_total_amount-fuck_pre_access * csv_data_session_unit_price)/1.05, 2))

                data_list.append(csv_4m_usage)
                data_list.append(csv_5m_usage)
                data_list.append(csv_6m_usage)
                data_list.append(csv_7m_usage)
                data_list.append(csv_8m_usage)
                data_list.append(csv_9m_usage)
                data_list.append(csv_10m_usage)
                data_list.append(csv_11m_usage)
                data_list.append(csv_12m_usage)
                data_list.append(csv_1m_usage)
                data_list.append(csv_2m_usage)
                data_list.append(csv_3m_usage)
                data_list.append(round((csv_total_amount - csv_year_recognize_amount)/1.05, 2))

                data_list.append(int(csv_4m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_5m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_6m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_7m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_8m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_9m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_10m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_11m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_12m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_1m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_2m_usage) * csv_data_session_unit_price)
                data_list.append(int(csv_3m_usage) * csv_data_session_unit_price)
                data_list.append(csv_total_recognize_amount)
                data_list.append(csv_total_recognize_amount_without_tax)
                data_list.append(csv_total_unrecognize_amount)
                data_list.append(csv_total_unrecognize_amount_without_tax)
                data_list.append(csv_paid_amount)
                data_list.append(csv_unpay_amount)
                data_list.append(csv_rebate_amount)
                data_list.append(csv_cancel_refound_amount)

                for csv_invoice_item in csv_invoice_list:
                    data_list.append(csv_invoice_item['p_date'])
                    data_list.append(csv_invoice_item['method'])
                    data_list.append(csv_invoice_item['amount'])
                    data_list.append("")
                    data_list.append(csv_invoice_item['date'])
                    data_list.append(csv_invoice_item['number'])

            if course_flag is True:
                export_list.append(data_list)

        return export_list

    def export_year_contract(self, target_year=None):

        if target_year is None:
            target_year = datetime.now().strftime("%Y")

        data_list = self._get_product(target_year)


        fieldnames = ['店鋪',
                      '客戶名稱',
                      '客戶編號',
                      '合約編號',
                      '負責教練',
                      '合約名稱',
                      '合約簽訂日期',
                      '合約總價(含稅)',
                      '合約原價(未稅)',
                      '合約狀態',
                      '合約堂數',
                      '已使用堂數',
                      '剩餘堂數',
                      '退費堂數',
                      '課程單價',
                      '課程單價(未稅)',
                      '前年度剩餘堂數',
                      '3/31之前已認列金額',
                      '3/31之前合約剩餘金額(未稅)',
                      '{}/4已使用'.format(target_year),
                      '{}/5已使用'.format(target_year),
                      '{}/6已使用'.format(target_year),
                      '{}/7已使用'.format(target_year),
                      '{}/8已使用'.format(target_year),
                      '{}/9已使用'.format(target_year),
                      '{}/10已使用'.format(target_year),
                      '{}/11已使用'.format(target_year),
                      '{}/12已使用'.format(target_year),
                      '{}/1已使用'.format(int(target_year) + 1),
                      '{}/2已使用'.format(int(target_year) + 1),
                      '{}/3已使用'.format(int(target_year) + 1),
                      '前年度未認列(未稅)',
                      '{}/4已認列'.format(target_year),
                      '{}/5已認列'.format(target_year),
                      '{}/6已認列'.format(target_year),
                      '{}/7已認列'.format(target_year),
                      '{}/8已認列'.format(target_year),
                      '{}/9已認列'.format(target_year),
                      '{}/10已認列'.format(target_year),
                      '{}/11已認列'.format(target_year),
                      '{}/12已認列'.format(target_year),
                      '{}/1已認列'.format(int(target_year) + 1),
                      '{}/2已認列'.format(int(target_year) + 1),
                      '{}/3已認列'.format(int(target_year) + 1),
                      '合約已認列收入',
                      '合約已認列收入(未稅)',
                      '合約未認列金額',
                      '合約未認列金額(未稅)',
                      '顧客已付(含稅)',
                      '未付款',
                      '折讓金額',
                      '退費金額'
                      ]

        for i in range(0, self._invoice_count):
            fieldnames.append("付款日")
            fieldnames.append("付款方式")
            fieldnames.append("金額")
            fieldnames.append("發票種類")
            fieldnames.append("發票發行日期")
            fieldnames.append("發票號碼")

        data_list.insert(0, fieldnames)

        self._csv_writer.export_csv(data_list)


class SessionProcess(object):
    def __init__(self):
        self._query_start_time = None
        self._query_end_time = None
        self._db_access = DBConnect()

        # RAW Data
        self._db_product_list = None
        self._db_contract_product_list = None

        # init the DB
        self._db_access.db_connect()

        # CSV transfer
        date_now = datetime.now()
        file_name = "Session_{}.csv".format(date_now.strftime("%Y-%m-%d_%H%M"))
        self._csv_writer = DataToCsv(file_name)

    def get_access_permission(self):
        try:
            sql_string = "SELECT * FROM [dbo].[ToolAccessKey]"
            access_list = self._db_access.get_data(sql_string)

            if access_list is None:
                Logger.write(Category.MainApp, Severity.WARNING, "Can not get the access list")
            else:
                Logger.write(Category.MainApp, Severity.INFO, "Get Access List as {}".format(access_list))
                Logger.write(Category.MainApp, Severity.INFO, "Get Key Access data as {}".format(access_list[0][0]))

                if access_list[0][0] == 1:
                    # Check Access Key
                    return True
                else:
                    return False

        except Exception as E:
            Logger.write(Category.MainApp, Severity.WARNING, "get_access_permissionFail, Get Error: {}".format(str(E)))

    def _get_product(self):
        export_list = []

        sql_string = "SELECT * FROM [dbo].[GuestManagementSaleses] where Category1 = 'Session'"
        checkin_list = self._db_access.get_data(sql_string)
        checkin_list2 = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractForms]"
        contract_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementMains]"
        guest_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[SettingCourse]"
        course_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[Staffs]"
        staff_list = self._db_access.get_data(sql_string)

        sql_string = "SELECT * FROM [dbo].[GuestManagementContractFormProducts]"
        product_list = self._db_access.get_data(sql_string)

        filter_list = []
        for checkin_item in checkin_list:
            if checkin_item[7] is not None:
                filter_list.append(checkin_item)

        new_list = []
        for sort_item in checkin_list2:
            if sort_item[7] is not None:
                new_list.append(sort_item)

        # Get year checkin record
        checkin_sort_list = sorted(new_list, key=lambda k: (k[4], k[7], k[5]))

        for attendances_item in filter_list:
            data_list = []
            csv_date = attendances_item[3]

            contract_id = attendances_item[9]
            staff_db_id = attendances_item[8]

            for staff_item in staff_list:
                if staff_item[0] == staff_db_id:
                    csv_saff_name = staff_item[5]

            for contract_item in contract_list:
                if contract_item[42] == contract_id:
                    csv_store_id = contract_item[99]
                    csv_user_name = contract_item[9]
                    admission_fee = contract_item[24]
                    Logger.write(Category.MainApp, Severity.INFO, "Admission fee = {}".format(admission_fee))

                    # Get the contract product item, if exist
                    contract_db_id = contract_item[0]
                    product_price = 0
                    for product_item in product_list:
                        if product_item[3] == contract_db_id:
                            # Find this contract exist the product
                            product_price = int(product_item[6]) * int(product_item[7])
                            if product_price != 0:
                                print("1~~~~~~~~~{}~~~~~~~~~~~~~~~~~~~".format(product_price))

                    # Get user id
                    guest_db_id = contract_item[4]
                    for guest_item in guest_list:
                        if guest_item[0] == guest_db_id:
                            csv_user_id = guest_item[6]

                    csv_contract_id = contract_item[42]
                    #csv_saff_name = contract_item[30]
                    csv_course_name = contract_item[27]
                    csv_coursse_id = contract_item[26]
                    csv_contract_createtime = contract_item[1]
                    csv_contract_starttime = contract_item[43]
                    csv_contract_surplusdate = contract_item[5]
                    csv_session_quantity = contract_item[44]
                    csv_session_suplus = contract_item[45]
                    csv_session_usage = int(csv_session_quantity) - int(csv_session_suplus)
                    csv_contract_length = 0
                    guest_db_id = contract_item[4]

                    now_date = datetime.now()
                    process_date = now_date - csv_contract_starttime
                    csv_processing_time = round(process_date.days / 30, 2)
                    csv_total_amount = contract_item[28]
                    csv_contract_status = contract_item[49]

                    for course_item in course_list:
                        if course_item[0] == csv_coursse_id:
                            csv_contract_length = course_item[10]

                    csv_session_count = 0
                    for checkin_item in filter_list:
                        # print("[2]=={} | {}".format(checkin_item[7], guest_db_id))
                        if checkin_item[7] == guest_db_id and checkin_item[9] == contract_id:
                            # find the check record, start fillter
                            #checkin_date = checkin_item[1].strftime("%Y-%m")
                            checkin_date = checkin_item[3].date()
                            print("[3] == {}-{} | {}".format(checkin_item[3], checkin_date, csv_date.date()))
                            if checkin_date <= csv_date.date():

                                csv_session_count += 1
                                csv_session_usage = csv_session_count

                    try:
                        Logger.write(Category.MainApp, Severity.INFO, "!! Admission fee = {} + product_price= {} / Total Amount = {}".format(admission_fee, product_price, csv_total_amount))
                        csv_data_session_unit_price = round((int(csv_total_amount)-int(admission_fee) - product_price) / int(csv_session_quantity), 2)
                        csv_data_session_unit_price_without_tax = round(csv_data_session_unit_price / 1.05, 2)
                        Logger.write(Category.MainApp, Severity.INFO,"Final unit price --> {}".format(csv_data_session_unit_price_without_tax))

                    except Exception as E:
                        Logger.write(Category.MainApp, Severity.WARNING, "WARNING--------{}----{}".format(csv_session_quantity, str(E)))
                        csv_data_session_unit_price = 0
                        csv_data_session_unit_price_without_tax = 0

            # Gen the data list
            data_list.append(csv_date.strftime("%Y-%m-%d"))
            data_list.append(csv_store_id)
            data_list.append(csv_user_name)
            data_list.append(csv_user_id)
            data_list.append(csv_contract_id)
            data_list.append(csv_saff_name)
            data_list.append(csv_course_name)
            data_list.append(csv_contract_length)
            data_list.append(csv_contract_createtime.strftime("%Y-%m-%d"))
            data_list.append(csv_contract_starttime.strftime("%Y-%m-%d"))
            data_list.append(csv_contract_surplusdate.strftime("%Y-%m-%d"))
            data_list.append(csv_processing_time)
            data_list.append(csv_total_amount)
            data_list.append(round(csv_total_amount / 1.05, 2))
            data_list.append(csv_contract_status)
            try:
                data_list.append(round(int(csv_session_usage) / csv_processing_time, 2))
            except Exception as E:
                Logger.write(Category.MainApp, Severity.WARNING, "Session process error:{} --- {}".format(csv_processing_time, str(E)))
                data_list.append(0)
            data_list.append(csv_session_count)

            if csv_contract_status == 'Withdrew':
                data_list.append(csv_session_quantity)
                data_list.append(csv_session_count)
                data_list.append(csv_session_quantity - csv_session_count)
                data_list.append(0)
                csv_total_recognize_amount = 0
                csv_total_recognize_amount_without_tax = 0
                csv_total_unrecognize_amount = csv_total_amount
                csv_total_unrecognize_amount_without_tax = round(csv_total_amount / 1.05, 2)

            else:
                data_list.append(csv_session_quantity)
                data_list.append(csv_session_count)
                data_list.append(0)
                data_list.append(csv_session_quantity - csv_session_count)
                csv_total_recognize_amount = int(csv_session_usage) * int(csv_data_session_unit_price)
                csv_total_recognize_amount_without_tax = round(csv_total_recognize_amount / 1.05, 2)
                csv_total_unrecognize_amount = csv_total_amount - csv_total_recognize_amount
                csv_total_unrecognize_amount_without_tax = round(csv_total_unrecognize_amount / 1.05, 2)

            data_list.append(csv_data_session_unit_price_without_tax)
            data_list.append(csv_total_recognize_amount)
            data_list.append(csv_total_recognize_amount_without_tax)
            data_list.append(csv_total_unrecognize_amount)
            data_list.append(csv_total_unrecognize_amount_without_tax)

            #data_list.append(fuck_sum)

            export_list.append(data_list)


        Logger.write(Category.MainApp, Severity.INFO, "Export list ---> {}".format(export_list))
        store_list = sorted(export_list, key=lambda k: (k[1], k[0]))

        tmp_store = None
        tmp_date = None
        fuck_sum = 0
        sort_count = 0
        for store_item in store_list:
            Logger.write(Category.MainApp, Severity.INFO, "Process store item ---{}/{}===={}|{}--{}".format(tmp_store,store_item[1], tmp_date,store_item[0], store_item[21]))
            if store_item[1] != tmp_store or store_item[0] != tmp_date:
                # dif store and dif date, reset default
                tmp_store = store_item[1]
                tmp_date = store_item[0]

                fuck_sum = store_item[21]
                sort_count = 0

            elif store_item[1] == tmp_store and tmp_date == store_item[0]:
                # mean same date
                fuck_sum += store_item[21]
                sort_count += 1

            else:
                Logger.write(Category.MainApp, Severity.INFO, "Error data check")

            store_item.insert(len(store_item), fuck_sum)
            store_item[16] = sort_count+1

        return store_list

    def export_session_with_date(self, start_date, end_date):
        data_list = self._get_product()
        final_list = []

        fieldnames = ['日期',
                      '店鋪',
                      '客戶名稱',
                      '客戶編號',
                      '合約編號',
                      '負責教練',
                      '合約名稱',
                      '合約時間',
                      '合約簽訂日期',
                      '合約開始日期',
                      '合約期限',
                      '合約已進行(月)',
                      '合約總價(含稅)',
                      '合約總價(未稅)',
                      '合約狀態',
                      '開始後來店頻率',
                      '堂數排序',
                      '合約堂數',
                      '合約已執行堂數',
                      '合約退會堂數',
                      '合約剩餘堂數',
                      '課程單價(未稅)',
                      '合約已認列金額',
                      '合約已認列金額(未稅)',
                      '合約未認列金額',
                      '合約未認列金額(未稅)',
                      '當日認列金額(未稅)'
                      ]

        for data_item in data_list:
            data_date = datetime.strptime(data_item[0], '%Y-%m-%d')
            if start_date <= data_date <= end_date:
                final_list.append(data_item)

        # final data list
        final_list.insert(0, fieldnames)
        self._csv_writer.export_csv(final_list)

    def export_product(self):
        fieldnames = ['日期',
                      '店鋪',
                      '客戶名稱',
                      '客戶編號',
                      '合約編號',
                      '負責教練',
                      '合約名稱',
                      '合約時間',
                      '合約簽訂日期',
                      '合約開始日期',
                      '合約期限',
                      '合約已進行(月)',
                      '合約總價(含稅)',
                      '合約原價(未稅)',
                      '合約狀態',
                      '開始後來店頻率',
                      '堂數排序',
                      '合約堂數',
                      '合約已執行堂數',
                      '合約退會堂數',
                      '合約剩餘堂數',
                      '課程單價(未稅)',
                      '合約已認列金額',
                      '合約已認列金額(未稅)',
                      '合約未認列金額',
                      '合約未認列金額(未稅)',
                      '當日認列金額(未稅)'
                      ]

        data_list = self._get_product()
        data_list.insert(0, fieldnames)
        self._csv_writer.export_csv(data_list)


if __name__ == '__main__':
    #PP = ProductProcess()
    #PP.export_product()

    #PA = AdmissionFeeProcess()
    #PA.export_product()

    PY = ContractYearProcess()
    PY.export_year_contract('2021')

    # SP = SessionProcess()
    # SP.export_product()
    #SP.export_session_with_date("2021/04/30", "2021/05/02")

