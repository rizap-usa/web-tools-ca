class StatusDefined():
    """
    Defined the status
    """
    Normal = 0
    Warning = 1
    Critical = 2