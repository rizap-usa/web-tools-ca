class OTAType(object):
    Windows = 1
    Ubuntu = 2
    debian = 3
    shelf = 4
    signage = 5

    service_names = {
            'Windows': "1",
            'Ubuntu': "2",
            'debian': "3",
            'shelf': "4",
            'signage': "5",
    }

    service_values = {
        "1": 'Windows',
        "2": 'Ubuntu',
        "3": 'debian',
        "4": 'shelf',
        "5": 'signage',
    }

    service_server = {
        'Windows',
        'Ubuntu',
        'debian',
    }

    service_device = {
        'shelf',
        'signage',
    }