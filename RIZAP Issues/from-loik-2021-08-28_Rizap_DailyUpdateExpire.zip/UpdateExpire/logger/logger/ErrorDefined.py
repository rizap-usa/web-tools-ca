class RetObj(object):
    ret_code = 0
    ret_data = None
    ret_msg = ""


class ErrorMapping(object):
    error_string_mapping = {
        0x0000000: "No Error",
        0X0010001: "Lose Private Key to Check DB Data",
        0x0010002: "lose Condition to Execute SQL",
        0x0010003: "DB Cannot Find The Search Target",
        0x0010004: "Execute SQL failed",
        0x0010005: "DB_Key_REPEAT",
        0x0010006: "Lose The Private Ke to Insert / Update Data",
        0x0010007: "Delete Target is Protected, Didn't Support Delete",
        0x001FFFF: "DB get Unknown Error",

        0X0020001: "Token Expired",
        0X0020002: "Token not Found",
        0X0020003: "User didn't Have Enough Permission To Access",
        0X0020004: "Invalid User Name or Password",
        0x0020005: "Invalid Token Id",
        0X0020006: "Cannot Save Token to DB",
        0X0020007: "Get User Info From DB Failed",

        0X0030001: "Cannot found available GW service exist",

        0X0040001: "Cannot found available SC service exist",

        0x0200001: "Client Send Wrong Parameter Format to Server",
        0x0200002: "Body Json Lose Key Parameter",
        0x0200003: "This request is not support local version",
        0x0200004: "Cannot connect to remote server",
        0x0200005: "Device license count is get limit",
        0x020FFFF: "Get HTTP Unknown Error",

        0x0300001: "Uncompress failed, get bad file.",
        0x0300002: "Uncompress failed, password invalid.",
        0x030FFFF: "Get Updater Unknown Error",
    }

    @classmethod
    def mapping_string(cls, error_code):
        return cls.error_string_mapping[error_code]

    @classmethod
    def return_message(cls, error_obj, data = 0):
        error_message = cls.error_string_mapping[error_obj.ret_code]
        ret_str = {'error_code': error_obj.ret_code, 'error_message': error_message, 'data': data, 'debug_message': error_obj.ret_msg}

        # Change json object to string format
        #ret_str = str(ret_str).replace('\'', '\"')
        import json
        ret_str = json.dumps(ret_str, ensure_ascii=False)

        return ret_str

class ErrorDefined(ErrorMapping):
    """
    Defined the error code with hex 7 byte
    it generate with Service type(3) + Action Result (4)
    Service defined DB/AD/SC ...
    Action defined get data failed with key violation
    """
    NO_ERROR = 0x0000000

    # DB Type = 001
    DB_LOSE_PRIVATE_KEY_TO_GET_DATA = 0X0010001
    DB_lOSE_CONDITION = 0X0010002
    DB_CANNOT_FIND_SEARCH_TARGET = 0x0010003
    DB_EXECUTE_SQL_ERROR = 0x0010004
    DB_KEY_REPEAT = 0x0010005
    DB_LOSE_PRIVATE_KEY_TO_INSERT_UPDATE_DATA = 0x0010006
    DB_DATA_PROTECTED_CANNOT_DELETE = 0x0010007
    DB_UNKNOWN_ERROR = 0x001FFFF

    # Auth Type = 002
    AUTH_TOKEN_EXPIRE = 0X0020001
    AUTH_TOKEN_NOT_FOUND = 0X0020002
    AUTH_TOKEN_PERMISSION_DENIED = 0X0020003
    AUTH_INVALID_ID_PASSWORD = 0X0020004
    AUTH_INVALID_TOKEN = 0x0020005
    AUTH_SAVE_TOKEN_FAILED = 0X0020006
    AUTH_GET_USER_INFO_FAILED = 0X0020007

    # GW Type = 003
    GW_SERVICE_NOT_EXIST = 0X0030001

    # SC Type = 004
    SC_SERVICE_NOT_EXIST = 0X0040001

    # HTTP Service = 020
    HTTP_SEND_WRONG_PARAMETER_TYPE_TO_SERVER = 0x0200001
    HTTP_LOSE_KEY_PARAMETER_IN_BODY = 0x0200002
    HTTP_NOT_SUPPORT_LOCAL = 0x0200003
    HTTP_SERVER_CANNOT_VISIT = 0x0200004
    
    HTTP_UNKNOWN_ERROR = 0x020FFFF

    # Updater = 030
    UPDATER_UNCOMPRESS_BAD_FILE = 0x0300001
    UPDATER_UNCOMPRESS_PASSWORD_INVALID = 0x0300002

    UPDATER_UNKNOW_ERROR = 0x030FFFF
