"""
File : category.py
Author : Loik Yeh

Purpose : Define the category used in Logger and Event.
"""


class Category(object):

    MainApp = 1
    DB = 2
    AUTH = 3
    SC = 4
    GW = 5
    WS = 6
    WEB = 7
    AGENT = 8
    WEBIPC = 9
    MT = 10
    WAITER = 11
    UDP = 12
    PP = 13
    UPDATER = 14

    category_names = {
        'MainApp': 1,
        'DB': 2,
        'AUTH': 3,
        'SC': 4,
        'GW': 5,
        'WS': 6,
        'WEB': 7,
        'AGENT': 8,
        'WEBIPC': 9,
        'MONITOR': 10,
        'WAITER': 11,
        'UDP': 12,
        'PP': 13,
        'UPDATER': 14
    }

    category_values = {
        1: 'MainApp',
        2: 'DB',
        3: 'AUTH',
        4: 'SC',
        5: 'GW',
        6: 'WS',
        7: 'WEB',
        8: 'AGENT',
        9: 'WEBIPC',
        10: 'MONITOR',
        11: 'WAITER',
        12: 'UDP',
        13: 'PP',
        14: 'UPDATER'
    }
