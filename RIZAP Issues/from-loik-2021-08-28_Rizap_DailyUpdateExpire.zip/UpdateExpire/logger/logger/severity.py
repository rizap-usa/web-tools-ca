class Severity(object):
    """Define the severities used in SystemLog and EventLog
    """
    VERBOSE = 0
    INFO = 1
    WARNING = 2
    CRITICAL = 3
    FATAL = 4

    def __init__(self):
        pass

    @staticmethod
    def to_string(severity):
        """
        Convert severity to friendly string

        :param severity:
        :return:
        """
        if severity < Severity.VERBOSE or severity > Severity.FATAL:
            return 'Unknown'

        names = ('Verbose', 'Info', 'Warning', 'Critical', 'Fatal')
        return names[severity]

    @staticmethod
    def to_short_name(severity):
        """
        Convert severity to a shorten name, 4 characters.

        :param severity:
        :return: string
        """
        return Severity.to_string(severity)[0:4]
