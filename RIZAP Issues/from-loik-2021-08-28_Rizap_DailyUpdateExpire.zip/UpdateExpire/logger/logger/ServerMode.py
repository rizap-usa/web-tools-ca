import os
import sys

class GetServerMode(object):
    def __init__(self):
        self.server_mode = 1
        self.fqdn = ""

    def get_server_mode(self):
        data_dict = self._load_file_setting()
        if data_dict is not None:
            self.server_mode = data_dict["server_mode"]
            self.fqdn = data_dict["fqdn"]
        ret_dict = {"server_mode": self.server_mode, "fqdn": self.fqdn}
        return ret_dict

    def _load_file_setting(self):
        try:
            with open(os.path.dirname(os.path.abspath(sys.argv[0])) + '/server_mode.inf') as fp:
                f_lines = fp.readlines()
            content = [x.strip() for x in f_lines]
            ret_dict = {}
            for server_setting in content:
                tmp_str = server_setting.replace(' ', '')
                tmp_info = tmp_str.split('=')
                if tmp_info[0] == 'mode':
                    ret_dict["server_mode"] = tmp_info[1]
                elif tmp_info[0] == 'static_fqdn':
                    ret_dict["fqdn"] = tmp_info[1]
            fp.close()
        except Exception as E:
            ret_dict = None
        finally:
            return ret_dict


class ServerMode(object):
    GServerMode = GetServerMode()
    data_dict = GServerMode.get_server_mode()
    server_mode = data_dict['server_mode']
    fqdn = data_dict['fqdn']