import os
import sys
import platform
import copy
from datetime import date
from .OTATypeDefine import OTAType
from logger import *
if sys.platform == "win32":
    import pywintypes, win32file, win32con
else:
    pass

try:
    import xml.etree.cElementTree as ElemTree
except ImportError:
    import xml.etree.ElementTree as ElemTree

class ServiceDescription(object):
    def __init__(self):
        self.ret_list = []

    def parser(self, path,Type):
        try:
            ret_dic = {}
            config_path = os.path.join(os.path.dirname(sys.argv[0]), path)
            tree = ElemTree.ElementTree(file=config_path)  # raise ElemTree.ParseError
            root = tree.getroot()
            for branch in root:
                if branch.attrib["type"] == OTAType.service_names[Type]:
                    for child in branch:
                        if child.tag == "MainVersion":
                            main_version = child[0].text
                            SType = child[1].text
                            FileName = child[2].text
                            ret_dic[child.tag] = {
                                "Version": main_version,
                                "Type": SType,
                                "FileName": FileName
                            }
                        else:
                            if child.tag != "SupportDBVersion" and child.tag != "Location" and child.tag != "Web":
                                self.ret_list.append(child.tag)
                            ret_dic[child.tag] = {}
                            for xml_node in child:
                                if xml_node.attrib:
                                    if xml_node.attrib['count'] == "0":
                                        ret_dic[child.tag][xml_node.tag] = []
                                    ret_dic[child.tag][xml_node.tag].append(xml_node.text)
                                else:
                                    ret_dic[child.tag][xml_node.tag] = xml_node.text
        except Exception as E:
            Logger.write(Category.UPDATER, Severity.WARNING, "Xml Parser get error : {0}".format(str(E)))
        return ret_dic

    def get_sublist(self, path,Type):
        parser = self.parser(path,Type)
        return self.ret_list