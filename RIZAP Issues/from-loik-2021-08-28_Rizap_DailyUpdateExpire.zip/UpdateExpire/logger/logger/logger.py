"""logger.py

Author:      Loik Yeh
Created:     06/24 2016
Copyright:   Loik Yeh
License:     no license
"""
import os
import sys
import threading
import inspect
import datetime
import socket
import copy
from datetime import date
from .severity import Severity
from .category import Category

if sys.platform == "win32":
    import pywintypes, win32file, win32con
else:
    pass

try:
    import xml.etree.cElementTree as ElemTree
except ImportError:
    import xml.etree.ElementTree as ElemTree


class _Config:
    def __init__(self):
        self.__path = './'
        self.__name = 'YDC_Sys.log'
        self.__db_flag = False
        self.__file_flag = True
        self.__console_flag = False
        self.__db_level = Severity.CRITICAL
        self.__file_level = Severity.INFO
        self.__console_level = Severity.VERBOSE
        self.__life_days = 30


    def set_file_location(self, path):
        self.__path = path

    def get_file_location(self):
        return self.__path

    def set_file_name(self, name):
        self.__name = name

    def get_file_name(self):
        return self.__name

    def set_write_db_flag(self, flag):
        assert isinstance(flag, bool)
        self.__db_flag = flag

    def get_write_db_flag(self):
        return self.__db_flag

    def set_write_file_flag(self, flag):
        assert isinstance(flag, bool)
        self.__file_flag = flag

    def get_write_file_flag(self):
        return self.__file_flag

    def set_write_console_flag(self, flag):
        assert isinstance(flag, bool)
        self.__console_flag = flag

    def get_write_console_flag(self):
        return self.__console_flag

    def set_db_level(self, level):
        self.__db_level = level

    def get_db_level(self):
        return self.__db_level

    def set_file_level(self, level):
        self.__file_level = level

    def get_file_level(self):
        return self.__file_level

    def set_console_level(self, level):
        self.__console_level = level

    def get_console_level(self):
        return self.__console_level

    def set_life_days(self, life_days):
        assert isinstance(life_days, int)
        self.__life_days = life_days

    def get_life_days(self):
        return self.__life_days

    def get_full_path_name(self):
        return os.path.join(self.get_file_location(), self.get_file_name())

    def get_archive_full_path_name(self):
        suffix = '_arc'
        return os.path.join(self.get_file_location(), self.get_file_name() + suffix)


class Logger:
    """This is a debug log engineer for trace and debug.
    """

    # private static member variable
    __instance = None

    def __init__(self):
        """ Construct function
        """
        # Check the static member `__instance` before continue initializing.
        # Stop the procedure if any other thread has initialized the `__instance`.
        # The `if` statements are not necessary.
        if Logger.__instance is None:
            try:
                self.__load_configuration_file()
            except ElemTree.ParseError:
                # ignore the error.  And, the default configuration has been loaded.
                # print "XML file parse error" % (str(E),)
                # with open("logger_loading.log", "a") as the_file:
                #     the_file.write("XML file parse error.\n")
                pass
            except IOError:
                # ignore the error.  And, the default configuration has been loaded.
                # print "XML file IO Error %s" % (str(E),)
                # with open("logger_loading.log", "a") as the_file:
                #     the_file.write("XML file IO Error.\n")
                pass
        if Logger.__instance is None:
            self.__hostname = socket.getfqdn()
        if Logger.__instance is None:
            self.__cond = threading.Condition()

    @staticmethod
    def __load_configuration_item(xml_node, configuration):
        """ Load an XML item value into configuration.

        :param xml_node: XML node
        :param configuration: instance of _Config, whose attribute will be overwritten by XML node value.
        :return: return False if the tag of XML node is not supported.
        """
        # with open("logger_loading.log", "a") as the_file:
        #     the_file.write("%s = %s\n" % (xml_node.tag, xml_node.text))

        if xml_node.tag == 'FileLocation':
            configuration.set_file_location(xml_node.text)
        elif xml_node.tag == 'FileName':
            configuration.set_file_name(xml_node.text)
        elif xml_node.tag == 'DBLevel':
            if xml_node.text.isdigit():
                configuration.set_db_level(int(xml_node.text))
        elif xml_node.tag == 'FileLevel':
            if xml_node.text.isdigit():
                configuration.set_file_level(int(xml_node.text))
        elif xml_node.tag == 'StdoutLevel':
            if xml_node.text.isdigit():
                configuration.set_console_level(int(xml_node.text))
        elif xml_node.tag == 'ToDB':
            if xml_node.text.lower() == 'true':
                configuration.set_write_db_flag(True)
            elif xml_node.text.lower() == 'false':
                configuration.set_write_db_flag(False)
        elif xml_node.tag == 'ToFile':
            if xml_node.text.lower() == 'true':
                configuration.set_write_file_flag(True)
            elif xml_node.text.lower() == 'false':
                configuration.set_write_file_flag(False)
        elif xml_node.tag == 'ToStdout':
            if xml_node.text.lower() == 'true':
                configuration.set_write_console_flag(True)
            elif xml_node.text.lower() == 'false':
                configuration.set_write_console_flag(False)
        elif xml_node.tag == 'LifeDays':
            if xml_node.text.isdigit():
                configuration.set_life_days(int(xml_node.text))
        else:
            return False
        return True

    def __load_configuration_file(self):
        """ Load configuration from XML file.

        :return: None
        :exception ElemTree.ParseError
        :exception IOError
        """
        # Set the default settings at first.
        default_config = _Config()
        self.__config_group = {'default': default_config}
        # config_path = os.path.abspath("./LogConfig.xml")
        config_path = os.path.join(os.path.dirname(sys.argv[0]), 'LogConfig.xml')
        # with open("logger_loading.log", "a") as the_file:
        #     the_file.write("Loading %s\n" % (config_path,))
        tree = ElemTree.ElementTree(file=config_path)  # raise ElemTree.ParseError
        root = tree.getroot()

        for child in root:
            if Logger.__load_configuration_item(child, default_config):
                pass
            elif child.tag == 'Categories':
                for category_item in child:
                    category_name = category_item.attrib.get('name', None)
                    if category_name and category_name in Category.category_names:
                        module_config = copy.copy(default_config)
                        for module_child in category_item:
                            Logger.__load_configuration_item(module_child, module_config)
                        self.__config_group[category_name] = module_config
                    # else:
                    #     print "Invalid category name '%s'" % (category_name,)

        # # dump the configuration group. debug only.
        # for name in self.__config_group:
        #     print '%s : %r' % (name, self.__config_group[name])
        #     for property, value in vars(self.__config_group[name]).iteritems():
        #         print property, ": ", value

    @staticmethod
    def __check_severity(configuration, severity):
        """ Compare the severity with configuration, then returns 3 boolean value to indicate whether to write
        logger to db, file or console.

        :param configuration: instance of _Config
        :param severity:
        :return: return 3 boolean values: write-to-db, write-to-file, write-to-console
        """
        assert isinstance(configuration, _Config)
        assert isinstance(severity, int)

        write_to_db = False
        write_to_file = False
        write_to_console = False
        if configuration.get_write_db_flag() and severity >= configuration.get_db_level():
            write_to_db = True
        if configuration.get_write_file_flag() and severity >= configuration.get_file_level():
            write_to_file = True
        if configuration.get_write_console_flag() and severity >= configuration.get_console_level():
            write_to_console = True

        return write_to_db, write_to_file, write_to_console

    def __get_category_active_configuration(self, category):
        """ Retrieve the configuration that matches the category from configuration group.

        :param category: an integer value of the category.
        :return: instance of _Config
        """
        assert category in Category.category_values
        assert 'default' in self.__config_group
        category_name = Category.category_values[category]
        configuration = self.__config_group.get(category_name, self.__config_group['default'])
        return configuration

    @staticmethod
    def __get_file_age_in_days(file_name):
        """ Retrieve number of days since the file was created.

        :param file_name:
        :return: return days since the file created.
        :exception WindowsError: The system cannot find the file.

        """
        assert isinstance(file_name, str)
        create_time = date.fromtimestamp(os.path.getctime(file_name))
        age = date.today() - create_time
        return age.days

    @staticmethod
    def __archive(file_name, archive_file_name):
        """ Rename from file_name to archive_file_name. Overwrite archive_file_name if it already exists.

        :return: No return
        :exception IOError: No such file or directory.
        """
        assert isinstance(file_name, str)
        assert isinstance(archive_file_name, str)

        try:
            if os.access(archive_file_name, os.F_OK):
                os.remove(archive_file_name)

            # Reset the file time than rename
            current_time = datetime.datetime.now()
            wintime = pywintypes.Time(current_time)
            winfile = win32file.CreateFile(
                file_name, win32con.GENERIC_WRITE,
                win32con.FILE_SHARE_READ | win32con.FILE_SHARE_WRITE | win32con.FILE_SHARE_DELETE,
                None, win32con.OPEN_EXISTING,
                win32con.FILE_ATTRIBUTE_NORMAL, None)

            win32file.SetFileTime(winfile, wintime, None, None)
            winfile.close()

            # Rename file
            os.rename(file_name, archive_file_name)

        except Exception as E:
            fp = open("tmp_log.txt", "a+")
            fp.write("get error-->{0}".format(E))
            fp.close()
            return False

        return True

    def __write(self, category, severity, message):
        """ Format the message and write to disk file and database.

        :param category:
        :param severity:
        :param message:
        :return:
        """
        # Get active configuration
        active_config = self.__get_category_active_configuration(category)
        write_to_db, write_to_file, write_to_console = Logger.__check_severity(active_config, severity)

        call_frame = inspect.stack()[2][0]
        now = datetime.datetime.now()
        string_now = now.strftime('%Y-%m-%d %H:%M:%S.%f')[0:-3]
        category_name = Category.category_values.get(category, '???')
        if severity in (Severity.FATAL, Severity.CRITICAL, Severity.WARNING):
            message_prefix = "[{}][{}:{}][{}.{}][L:{}]".format(Severity.to_short_name(severity), os.getpid(),
                                                               threading.currentThread().ident, category_name,
                                                               call_frame.f_code.co_name, call_frame.f_lineno)
        else:
            message_prefix = "[{}][{}:{}][{}.{}]".format(Severity.to_short_name(severity), os.getpid(),
                                                         threading.currentThread().ident, category_name,
                                                         call_frame.f_code.co_name)

        if write_to_file:
            self.__cond.acquire()
            try:
                # Archive the logger file after a few days.
                try:
                    file_age = Logger.__get_file_age_in_days(active_config.get_full_path_name())
                    if file_age >= active_config.get_life_days():
                        Logger.__archive(active_config.get_full_path_name(),
                                         active_config.get_archive_full_path_name())
                except OSError:  # Failed to get file age, because the logger file does not exist.
                    pass

                # Open logger file and write the logger message.
                with open(active_config.get_full_path_name(), 'a+') as file_handle:
                    file_handle.write('[{}]{}{}\n'.format(string_now, message_prefix, message))
            finally:
                self.__cond.release()

        if write_to_console:
            self.__cond.acquire()
            try:
                print ('[{}]{}{}'.format(string_now, message_prefix, message))
            finally:
                self.__cond.release()


        if write_to_db:
            from dao.dbo import ServiceLog

            service_log = ServiceLog()
            try:
                param = {
                    "service_type": category,
                    "service_fqdn": self.__hostname,
                    "severity": severity,
                    "log_tittle": '',
                    "log_data": '{}{}'.format(message_prefix, message),
                    }

                print(param)

                service_log.insert(param)
            except Exception as e:
                # Catch the exception while write database and record it into disk file.
                self.__cond.acquire()
                try:
                    with open(active_config.get_full_path_name(), 'a+') as file_handle:
                        file_handle.write('find error = ' + str(e))
                finally:
                    self.__cond.release()

    @staticmethod
    def write(category, severity, message):
        """ Write a log message with severity into a disk log file and database.

        :param category: The category of log.  Refer to category.py.
        :param severity: Refer to Severity.py
        :param message: The string message to be written. Do not add EOL at the end of message.
        :return: No return.
        """
        assert isinstance(category, int)
        assert isinstance(severity, int)
        assert isinstance(message, str)

        if Logger.__instance is None:
            new_instance = Logger()
            if Logger.__instance is None:
                Logger.__instance = new_instance
            else:
                pass  # the new_instance will be abandoned.

        # Catch the exception when writing log.  Do not crash it by logger.
        try:
            Logger.__instance.__write(category, severity, message)
        except:
            pass


'''
from threading import Thread

def thread_func():
    for x in range(0, 50):
        Logger.write(Category.CAMERA_AUTH_SERVER, Severity.VERBOSE, 'hello 1')
        Logger.write(Category.CAMERA_AUTH_SERVER, Severity.INFO, 'Hello 2')
        Logger.write(Category.CAMERA_AUTH_SERVER, Severity.WARNING, 'Hello 2')
        Logger.write(Category.CAMERA_AUTH_SERVER, Severity.CRITICAL, 'Hello 2')
        Logger.write(Category.CAMERA_AUTH_SERVER, Severity.FATAL, 'Hello 2')
        Logger.write(Category.VMS_CLI, Severity.VERBOSE, 'hello 1')
        Logger.write(Category.VMS_CLI, Severity.INFO, 'Hello 2')
        Logger.write(Category.VMS_CLI, Severity.WARNING, 'Hello 2')
        Logger.write(Category.VMS_CLI, Severity.CRITICAL, 'Hello 2')
        Logger.write(Category.VMS_CLI, Severity.FATAL, 'Hello 2')


def main():
    dbo.Init('192.168.250.120', 'sa', 'Abc.123', 'surveillance_cloud')
    thread1 = Thread(target=thread_func)
    thread2 = Thread(target=thread_func)
    thread3 = Thread(target=thread_func)

    thread1.start()
    thread2.start()
    thread3.start()

    thread1.join()
    thread2.join()
    thread3.join()


def single_thread_main():
    dbo.Init('192.168.250.120', 'sa', 'Abc.123', 'surveillance_cloud')
    Logger.write(Category.CAMERA_AUTH_SERVER, Severity.VERBOSE, 'hello 1')
    Logger.write(Category.CAMERA_AUTH_SERVER, Severity.INFO, 'Hello 2')
    Logger.write(Category.CAMERA_AUTH_SERVER, Severity.WARNING, 'Hello 2')
    Logger.write(Category.CAMERA_AUTH_SERVER, Severity.CRITICAL, 'Hello 2')
    Logger.write(Category.CAMERA_AUTH_SERVER, Severity.FATAL, 'Hello 2')
    Logger.write(Category.VMS_CLI, Severity.VERBOSE, 'hello 1')
    Logger.write(Category.VMS_CLI, Severity.INFO, 'Hello 2')
    Logger.write(Category.VMS_CLI, Severity.WARNING, 'Hello 2')
    Logger.write(Category.VMS_CLI, Severity.CRITICAL, 'Hello 2')
    Logger.write(Category.VMS_CLI, Severity.FATAL, 'Hello 2')


if __name__ == '__main__':
    single_thread_main()
    # main()
'''
