import os
from setuptools import setup
import logger


def read(file_name):
    return open(os.path.join(os.path.dirname(__file__), file_name)).read()


setup(
    name='logger',
    version=logger.__version__,
    author='Loik Yeh',
    author_email='Loik.Yeh@coretronic',
    description='An debug logger tool and event tool.',
    license='',
    keywords='',
    url='',
    packages=['logger'],
    long_description=read('README'),
    classifiers=[
        "Development Status :: 1 - Alpha",
        "Topic :: Utilities",
        "License :: OSI Approved :: BSD License",
    ],
)
