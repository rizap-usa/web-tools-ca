﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Quartz;
using Quartz.Spi;
using Rizap.Data;
using Rizap.Models;

namespace Rizap.Scheduler
{
    /// <summary>
    /// 建立可供 ASP.NET Core 注入的 JobFactory。
    /// 如此才能使用如 EF Core 相關的服務
    /// </summary>
    public class SingletonJobFactory : IJobFactory
    {
        private readonly IServiceProvider _serviceProvider;
        /// <summary>
        /// SingletonJobFactory
        /// </summary>
        /// <param name="serviceProvider"></param>
        public SingletonJobFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        }
        /// <summary>
        /// 傳回委託的 IServiceProvider 以便 DI 可以使用，但過程中需以 IJob 包裝以便於傳出
        /// </summary>
        /// <param name="bundle"></param>
        /// <param name="scheduler"></param>
        /// <returns></returns>
        public IJob NewJob(TriggerFiredBundle bundle, IScheduler scheduler)
        {
            var iserviceProvider = _serviceProvider.GetRequiredService(bundle.JobDetail.JobType) as IJob;
            return iserviceProvider;
        }

        /// <summary>
        /// 回傳 Job
        /// </summary>
        /// <param name="job"></param>
        public void ReturnJob(IJob job)
        {

        }
    }

    /// <summary>
    /// 使用 Quartz.NET 建立可自動常時間執行的背景程序
    /// </summary>
    public class SchedulerService
    {
        /// <summary>
        /// RIZAP KPI Scheduler Job。執行自動掃描 KPI 所需的運算內容 (57 個公式)
        /// </summary>
        [DisallowConcurrentExecution]
        public class RizapKpiSchedulerJob : IJob
        {
			// 注入 DI provider
	        private readonly IServiceProvider _provider;
	        private readonly ILogger<RizapKpiSchedulerJob> _logger;

            /// <summary>
            /// 接収注入服務
            /// </summary>
            /// <param name="logger"></param>
            /// <param name="provider"></param>
            public RizapKpiSchedulerJob(
	            ILogger<RizapKpiSchedulerJob> logger, 
	            IServiceProvider provider
	        ) {
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
                _provider = provider;
            }

            public Task Execute(IJobExecutionContext context)
            {
				// 創建一個新的作用域
				using (var scope = _provider.CreateScope())
				{
					// 解析使用的作用域服務（例如 EF Core 或其他服務）
					var dbContext = scope.ServiceProvider.GetService<GuestManagementDbContext>();

					try
					{
						if (dbContext != null)
						{
#if DEBUG
                            var devpStatus = "DEBUG";
#else
							var devpStatus = "RELEASE";
#endif
                            // 找出有幾個 Country 有幾個 StoreId
                            var countryAndStoreIdList = dbContext.SettingStoreInformation
	                            .Select(s => new
	                            {
		                            CountryId = s.Country,
		                            StoreId = s.StoreId,
		                            StoreName = s.StoreName_EN
	                            })
	                            .ToList();

                            foreach (var t in countryAndStoreIdList)
                            {
	                            _logger.LogWarning($"[{devpStatus}] KPI Scheduler: Scanning Country={t.CountryId}, StoreId={t.StoreId} ({t.StoreName}) - {DateTime.Now: yyyy-MM-dd HH:mm:ss}");

	                            var server = "";
#if DEBUG
	                            server = "https://localhost:44323";
#elif RELEASEOFFICAL
								server = "https://rizap-offical.azurewebsites.net";
#else
								server = "https://rizap.azurewebsites.net";
#endif
	                            var url = $"{server}/KPISnapshot/KpiSnapshotUpdateApi?country={t.CountryId}&storeId={t.StoreId}";
                                var myWebRequest = WebRequest.Create(url);
	                            var myWebResponse = myWebRequest.GetResponse();
                            }

                            _logger.LogWarning($"[{devpStatus}] KPI Scheduler: Run {DateTime.Now: yyyy-MM-dd HH:mm:ss}");
                        }
					}
					catch (Exception e)
					{
						Console.WriteLine(e);
                        _logger.LogError($"EXCEPTION (KPI Scheduler): {e}");
					}
				}
				return Task.CompletedTask;
            }
        }

        /// <summary>
        /// RIZAP Contract Scheduler Job。執行自動掃描合約，計算需變更的狀態
        /// </summary>
        [DisallowConcurrentExecution]
        public class RizapContractSchedulerJob : IJob
        {
            // 注入 DI provider
            private readonly IServiceProvider _provider;
            private readonly ILogger<RizapContractSchedulerJob> _logger;

            /// <summary>
            /// 接収注入服務
            /// </summary>
            /// <param name="logger"></param>
            /// <param name="provider"></param>
            public RizapContractSchedulerJob(
                ILogger<RizapContractSchedulerJob> logger,
                IServiceProvider provider
            ) {
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
                _provider = provider;
            }

            public Task Execute(IJobExecutionContext context)
            {
#if DEBUG
                var devpStatus = "DEBUG";
#else
                var devpStatus = "RELEASE";
#endif

                var perfSw= new Stopwatch();

                // 創建一個新的作用域
                using(var scope = _provider.CreateScope())
                {
                    // 解析使用的作用域服務（例如 EF Core 或其他服務）
                    var dbContext = scope.ServiceProvider.GetService<GuestManagementDbContext>();

                    try
                    {
                        if(dbContext != null)
                        {
                            // 記量執行時間
							perfSw.Start();

	                        #region 若合約逾期﹑延展逾期，變更合約狀態為 Completed
                            try
                            {
                                // 取得所有有效合約
                                var cfList = dbContext.GuestManagementContractForms.Where(f =>
                                    /* 合約含有課程或商品 (Year / Standard)，並非只有商品 (Others) */
	                                f.CourseType != "Others" &&
	                                (f.ContractStatus == "Contracted" || f.ContractStatus == "On Work" || f.ContractStatus == "Extended/ On Work")
	                            ).ToList();

                                if(cfList != null && cfList.Count > 0)
                                {
                                    foreach(var t in cfList)
                                    {
                                        var currentDate = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, DateTime.UtcNow.Day);

                                        // 此合約為正常
                                        if((t.ContractStatus == "Contracted" || t.ContractStatus == "On Work") && t.ExpirationDate != DateTime.MinValue)
                                        {
                                            // 由於是 23:59 執行，合約等於當天等同於到期，將合約改為 Completed
                                            var expDate = new DateTime(t.ExpirationDate.Year, t.ExpirationDate.Month, t.ExpirationDate.Day);
                                            if(currentDate == expDate)
                                            {
                                                儲存合約狀態為完成(dbContext, t);
                                            }
                                        }
                                        // 此合約為延展
                                        else
                                        {
                                            if(t.CourseExtensionExpirationTime != DateTime.MinValue)
                                            {
                                                // 由於是 23:59 執行，合約等於當天等同於到期，將合約改為 Completed
                                                var expDate = new DateTime(t.CourseExtensionExpirationTime.Year, t.CourseExtensionExpirationTime.Month, t.CourseExtensionExpirationTime.Day);
                                                if(currentDate == expDate)
                                                {
                                                    儲存合約狀態為完成(dbContext, t);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                                _logger.LogError($"EXCEPTION (Contract Scheduler)-(處理合約逾期﹑延展逾期，變更合約狀態為 Completed): {e}");
                            }
                            #endregion

                            #region 若當天未上課，將預約刪除並歸還一次課程到合約中的剩餘課程數 (2020.10.21取消自動返回為認列課程)
                            //                 // 取得今天完全沒打卡的預約課程
                            //                 var resvList = dbContext.Reservations.Where(f =>
                            //                   (f.StartTime.Year == DateTime.Now.Year && 
                            //                    f.StartTime.Month == DateTime.Now.Month && 
                            //                    f.StartTime.Day == DateTime.Now.Day) &&
                            //                   (f.Check == false))
                            //                  .ToList();

                            //                 // 1. 將預約刪除
                            //                 foreach (var resv in resvList)
                            //                 {
                            //                  try
                            //                  {
                            //                         dbContext.Reservations.Remove(resv);
                            //                         if(dbContext.SaveChanges() >= 1)
                            //                         {
                            //                             // 2. 將合約剩餘課程數返還一堂
                            //                             var cfDbId = resv.ContractDbId;
                            //                             var cf = dbContext.GuestManagementContractForms.Find(cfDbId);
                            //                             if (cf == null) continue;

                            //                             // 進行欄位更新
                            //                             dbContext.GuestManagementContractForms.Attach(cf);
                            //                             if (cf.CourseSessionSurplus < cf.CourseSessionQuantity)
                            //                             {
                            //cf.CourseSessionSurplus++;
                            //                                 dbContext.Entry(cf).Property(p => p.CourseSessionSurplus).IsModified = true;

                            //                                 cf.LastUpdateTime = DateTime.Now;
                            //                                 dbContext.Entry(cf).Property(p => p.LastUpdateTime).IsModified = true;
                            //                             }

                            //                             if (dbContext.SaveChanges() >= 1)
                            //                             {
                            //_logger.LogWarning($"[{devpStatus}] Contract Scheduler: return back 1 session to {cf.ContractId}");
                            //                             }
                            //                         }
                            //                     }
                            //                     catch (Exception e)
                            //                  {
                            //                         Console.WriteLine(e);
                            //                         _logger.LogError($"EXCEPTION (Contract Scheduler)-(處理當天未上課，將課程預約歸還): {e}");
                            //                     }
                            //                 }
                            #endregion

                            #region 若合約 .CourseSalesRecognition = "By each month" 則月底才認列寫入 GM.Sales 欄位中
                            // 若今天已是當月最後一天則觸發進行月認列 (透過加一天來判斷月份是否有變動)
                            if (DateTime.UtcNow.AddDays(1).Month != DateTime.UtcNow.Month)
                            {
                                // 找出 .CourseSalesRecognition = "By each month" 的合約，這些合約不會在每次有從 GM.Order 進行付費時就寫入 GM.Sales，而是在每月月底才寫入
                                var contractListInCourseSalesByEachMonth = dbContext.GuestManagementContractForms
	                                .Include(i1=>i1.PaymentSchedules)
	                                .Where(f => f.CourseSalesRecognition == "By each month")
									.ToList();

                                foreach (var t in contractListInCourseSalesByEachMonth)
                                {
                                    if (t.PaymentSchedules == null || t.PaymentSchedules.Count == 0) continue;

                                    // 合約含 課程 + 商品
                                    if (t.CourseType != "Others")
                                    {
	                                    try
	                                    {
		                                    // 第零筆一定為 商品 + Admission Fee (已在前端驗證並由前端提交後端時分別寫入 Product & Addmission Fee 到 GM.Sales)

                                            // 處理第二筆以上，已屬於課程範圍
                                            var sessionProcessedCount = 0;
                                            double sessionTotalPaid = 0;
                                            for(var x = 1; x < t.PaymentSchedules.Count; x++)
                                            {
	                                            var currentPaid = t.PaymentSchedules.ToList()[x];

                                                dbContext.GuestManagementSaleses.Add(new GuestManagementSales() {
		                                            Date = DateTime.UtcNow,
		                                            Category1 = "Session",
		                                            Category2 = t.CourseName,
		                                            TotalPrice = currentPaid.PaidAmount,

		                                            GuestManagementMainId = t.GuestDbId,
		                                            StaffGuid = t.StaffDbId,

		                                            ContractId = t.ContractId,
		                                            LastUpdateTime = DateTime.UtcNow
	                                            });
                                                sessionTotalPaid += currentPaid.PaidAmount;
                                                sessionProcessedCount++;
                                            }
                                            if (sessionProcessedCount > 0)
                                            {
	                                            if(dbContext.SaveChanges() >= 1)
	                                            {
		                                            _logger.LogWarning($"[{devpStatus}] Contract Scheduler: 月結算銷售 {t.ContractFormProducts.Count} 筆 (課程) 金額 {sessionTotalPaid}（合約ID={t.ContractId}）");
	                                            }
                                            }
                                        }
	                                    catch (Exception e)
	                                    {
		                                    Console.WriteLine(e);
		                                    _logger.LogError($"EXCEPTION (Contract Scheduler)-(月結算銷售 (商品 + Admission Fee + 課程), 合約ID={t.ContractId}): {e}");
                                        }
                                    }
                                    // 合約只有 商品：200514, 只有商品時第一筆款項一定是全額付清 (已在前端驗證並寫入)
                                    else
                                    {
	                                    try
	                                    {
		                                    if (t.PaymentSchedules.Count >= 1)
		                                    {
			                                    var paidRecord = t.PaymentSchedules.ToList()[0];

                                                // 若當月有付款，則列入月結算銷售
                                                if(paidRecord.PaidDate.Year == DateTime.UtcNow.Year &&
                                                   paidRecord.PaidDate.Month == DateTime.UtcNow.Month
                                                ) {
	                                                if (t.ContractFormProducts == null) continue;

                                                    // 將每筆商品寫入
                                                    foreach (var product in t.ContractFormProducts)
                                                    {
	                                                    dbContext.GuestManagementSaleses.Add(new GuestManagementSales() {
		                                                    Date = DateTime.UtcNow,
		                                                    Category1 = "Product",
		                                                    Category2 = $"{product.ProductName} x{product.ProductQuantity}",
		                                                    TotalPrice = product.ProductQuantity * product.ProductUnitPrice,

		                                                    GuestManagementMainId = t.GuestDbId,
		                                                    StaffGuid = t.StaffDbId,

		                                                    ContractId = t.ContractId,
		                                                    LastUpdateTime = DateTime.UtcNow
	                                                    });
                                                    }

                                                    if(dbContext.SaveChanges() >= 1)
                                                    {
	                                                    _logger.LogWarning($"[{devpStatus}] Contract Scheduler: 月結算銷售 {t.ContractFormProducts.Count} 筆 (只有商品) 金額 {paidRecord.PaidAmount}（合約ID={t.ContractId}）");
                                                    }
                                                }
                                            }
                                        }
	                                    catch (Exception e)
	                                    {
		                                    Console.WriteLine(e);
		                                    _logger.LogError($"EXCEPTION (Contract Scheduler)-(月結算銷售 (只有商品), 合約ID={t.ContractId}): {e}");
                                        }
                                    }
                                }
                            }
#endregion

                            #region 若合約只有商品且已於 ContractStatus = "On Work"，則七天後將合約狀態改為 "Completed"
                            try
                            {
	                            var productOnlyCfList = dbContext.GuestManagementContractForms
		                            .Where(f =>
			                            /* 合約只有商品沒有課程 */
			                            f.CourseType == "Others" &&
			                            /* 合約狀態為 On Work */
			                            f.ContractStatus == "On Work")
		                            .ToList();

	                            foreach(var t in productOnlyCfList)
	                            {
		                            var currentDate = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, DateTime.UtcNow.Day);
		                            var startDate = new DateTime(t.StartTime.Year, t.StartTime.Month, t.StartTime.Day);

		                            if(currentDate.Subtract(startDate).TotalDays >= AppSetting.商品鑑賞天數)
		                            {
			                            dbContext.GuestManagementContractForms.Attach(t);

			                            t.ContractStatus = "Completed";
			                            dbContext.Entry(t).Property(x => x.ContractStatus).IsModified = true;
			                            t.LastUpdateTime = DateTime.UtcNow;
			                            dbContext.Entry(t).Property(x => x.LastUpdateTime).IsModified = true;

			                            if(dbContext.SaveChanges() >= 1)
			                            {
				                            _logger.LogWarning($"[{devpStatus}] Contract Scheduler: 商品鑑賞期已到，設置合約 {t.ContractId} 狀態為 Completed");
			                            }
		                            }
	                            }
                            }
                            catch (Exception e)
                            {
	                            Console.WriteLine(e);
	                            _logger.LogError($"EXCEPTION (Contract Scheduler)-(商品鑑賞期已到的合約狀態為 Completed): {e}");
                            }
#endregion

                            perfSw.Stop();
                            _logger.LogWarning($"[{devpStatus}] Contract Scheduler: Take Time {perfSw.ElapsedMilliseconds:N0}ms");
                        }
                    }
                    catch(Exception e)
                    {
                        Console.WriteLine(e);
                        _logger.LogError($"EXCEPTION (Contract Scheduler): {e}");
                    }
                }
                return Task.CompletedTask;

				#region Inner Function
                void 儲存合約狀態為完成(GuestManagementDbContext context, ContractForm c)
                {
	                if (context == null) return;

                    context.GuestManagementContractForms.Attach(c);

                    c.ContractStatus = "Completed";
                    context.Entry(c).Property(x => x.ContractStatus).IsModified = true;

                    if(context.SaveChanges() >= 1)
                    {
                        _logger.LogWarning($"[{devpStatus}] Contract Scheduler: ContractID '{c.ContractId}' Status Change to 'Completed'");

                        // 紀錄剩餘課程數剩餘的價值，並寫到 Sales
                        if (c.CourseSessionSurplus > 0)
                        {
                            var sessionUnitValue = 0.0;

                            if (c.CourseAmountDiscountCoupon == 0)
                            {
                                sessionUnitValue = (c.CourseAmount / c.CourseSessionQuantity) * c.CourseSessionSurplus;
                            }
                            else
                            {
                                sessionUnitValue = (c.CourseAmountDiscountCoupon / c.CourseSessionQuantity) * c.CourseSessionSurplus;
                            }

                            //假設剩餘未上課金額>實際付款的金額=實際付款的金額
                            if (c.ActualPayment< sessionUnitValue)
                            {
                                sessionUnitValue = c.ActualPayment;
                            }

	                        context.GuestManagementSaleses.Add(new GuestManagementSales()
	                        {
		                        Date = DateTime.Now,
		                        GuestManagementMainId = c.GuestManagementMainId,
		                        StaffGuid = c.StaffDbId,

		                        StoreId = c.StoreId,
		                        ContractId = c.ContractId,
		                        Category1 = "Session",
		                        Category2 = "Contract Completed",
		                        TotalPrice = sessionUnitValue
	                        });

	                        if (context.SaveChanges() >= 1)
	                        {
		                        _logger.LogWarning($"[{devpStatus}] Contract Scheduler: ContractID '{c.ContractId}' Save to Sales 'Contract Completed'");
                            }
                        }
                    }
                }
				#endregion
            }
        }

        /// <summary>
        /// RIZAP deleteLog clear Scheduler Job。執行清理deleteLog動作，把超過兩年的deleteLog清除。
        /// </summary>
        [DisallowConcurrentExecution]
        public class RizapDeletelogClearSchedulerJob : IJob
        {
            // 注入 DI provider
            private readonly IServiceProvider _provider;
            private readonly ILogger<RizapDeletelogClearSchedulerJob> _logger;

            /// <summary>
            /// 接収注入服務
            /// </summary>
            /// <param name="logger"></param>
            /// <param name="provider"></param>
            public RizapDeletelogClearSchedulerJob(
                ILogger<RizapDeletelogClearSchedulerJob> logger,
                IServiceProvider provider
            )
            {
                _logger = logger ?? throw new ArgumentNullException(nameof(logger));
                _provider = provider;
            }

            public Task Execute(IJobExecutionContext context)
            {
#if DEBUG
                var devpStatus = "DEBUG";
#else
                var devpStatus = "RELEASE";
#endif

                var perfSw = new Stopwatch(); // 記量執行時間
                // 創建一個新的作用域
                using (var scope = _provider.CreateScope())
                {
                    // 解析使用的作用域服務（例如 EF Core 或其他服務）
                    var dbContext = scope.ServiceProvider.GetService<GuestManagementDbContext>();
                    try
                    {
                        if (dbContext != null)
                        {
                            perfSw.Start();
                            try
                            {
                                if (System.IO.Directory.Exists(@".\deleteLog"))
                                {
                                    string[] files = Directory.GetFiles(@".\deleteLog"); 
                                    
                                    foreach (string file in files)
                                    {
                                        FileInfo fi = new FileInfo(file);
                                        if (fi.LastAccessTime < DateTime.Now.AddYears(-2))
                                            fi.Delete();
                                    }
                                }
                            }
                            catch (Exception e)
                            {
                                Console.WriteLine(e);
                                _logger.LogError($"EXCEPTION (DeletelogClear Scheduler): {e}");
                            }

                            perfSw.Stop();
                            _logger.LogWarning($"[{devpStatus}] Contract Scheduler: Take Time {perfSw.ElapsedMilliseconds:N0}ms");
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        _logger.LogError($"EXCEPTION (Contract Scheduler): {e}");
                    }
                }
                return Task.CompletedTask;
            }
        }
    }
}
